ALTER TABLE `shopifyStores` ADD `companyId` int;
